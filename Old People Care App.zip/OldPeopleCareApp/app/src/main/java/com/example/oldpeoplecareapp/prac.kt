package com.example.oldpeoplecareapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import com.example.oldpeoplecareapp.databinding.FragmentPracBinding

class prac : Fragment() {
    lateinit var binding:FragmentPracBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        binding = FragmentPracBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



//        val items = listOf("Material", "Design", "Components", "Android")
//        val adapter= ArrayAdapter(requireContext(), R.layout.list_item, items)
//        adapter.setDropDownViewResource(R.layout.list_item)
//        binding.spinner.adapter=adapter
//        binding.spinner.onItemSelectedListener=object :AdapterView.OnItemSelectedListener{
//            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
//                TODO("Not yet implemented")
//            }
//
//            override fun onNothingSelected(parent: AdapterView<*>?) {
//                TODO("Not yet implemented")
//            }
//
//
//        }
    }


}