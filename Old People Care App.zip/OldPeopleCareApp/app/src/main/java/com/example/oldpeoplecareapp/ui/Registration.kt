package com.example.oldpeoplecareapp.ui

import android.app.DatePickerDialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.example.oldpeoplecareapp.R
import com.example.oldpeoplecareapp.databinding.FragmentRegistrationBinding
import com.example.oldpeoplecareapp.model.entity.UserPost
import com.example.oldpeoplecareapp.model.remote.RemoteRepositoryImp
import com.example.oldpeoplecareapp.model.remote.RetroBuilder
import com.example.oldpeoplecareapp.model.remote.ServiceAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.util.*
import androidx.core.content.ContextCompat.getSystemService

class Registration : Fragment() {
    lateinit var binding: FragmentRegistrationBinding
    lateinit var remoteRepositoryImp: RemoteRepositoryImp

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        binding = FragmentRegistrationBinding.inflate(inflater, container, false)
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        val serviceInstant = RetroBuilder.builder
        remoteRepositoryImp = RemoteRepositoryImp(serviceInstant)
        val calendar=Calendar.getInstance()
        val year=calendar.get(Calendar.YEAR)
        val month=calendar.get(Calendar.MONTH)
        val day=calendar.get(Calendar.DAY_OF_MONTH)

        val gender = listOf("Male", "Female")
        val adapterG = ArrayAdapter(requireContext(), R.layout.list_item, gender)
        (binding.genderX.editText as? AutoCompleteTextView)?.setAdapter(adapterG)

        val register = listOf("Patient", "Care Giver")
        val adapterR = ArrayAdapter(requireContext(), R.layout.list_item, register)
        (binding.registerAsX.editText as? AutoCompleteTextView)?.setAdapter(adapterR)

        binding.DateOfBirth.setOnClickListener {

            val datePickerDialog=DatePickerDialog(requireContext(),DatePickerDialog.OnDateSetListener { it, year, month, dayOfMonth ->
                binding.DateOfBirth.text = "   $year-$month-$dayOfMonth"
            },year,month,day)
            datePickerDialog.show()
        }
        binding.add.setOnClickListener {
            val fullname = binding.fullname.text.toString()
            val email = binding.email.text.toString()
            val phone = binding.phone.text.toString()
            val dateOfBirth = binding.DateOfBirth.text.toString()
            val gender = binding.genderX.isSelected.toString()
            val registerAs = binding.registerAsX.isSelected.toString()
            val password = binding.password.text.toString()

            GlobalScope.launch(Dispatchers.IO) {
                val result = remoteRepositoryImp.addNewUser(
                    fullname,
                    email,
                    phone,
                    dateOfBirth,
                    gender,
                    registerAs,
                    password
                )
                Log.i("before", result.toString())
                if (result.isSuccessful) {
                    Log.i("done", result.toString())
                } else {
                    Log.i("ERROR_GET", result.toString())
                }
            }
        }
    }
}













//                val result = remoteRepositoryImp.addNewUser(
//                        "mancy",
//                        "abdel@gmail.com",
//                        "01554500089",
//                        "2002-12-09",
//                        "Male",
//                        "Patient",
//                        "12AAA4599789Abdl@"
//
//                )


//        binding.DateOfBirth.setOnClickListener {
//            val imm = activity?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
//            imm.hideSoftInputFromWindow(requireView().windowToken, 0)
//        }