package com.example.oldpeoplecareapp.model.remote

import com.example.oldpeoplecareapp.model.entity.UserPost
import com.example.oldpeoplecareapp.model.entity.UserResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Query

interface RemoteRepository {
    suspend fun addNewUser(
        fullname: String,
        email: String,
        phone: String,
        dateOfBirth: String,
        gender: String,
        registAs: String,
        password: String
    ): Response<UserResponse>
}














  //  suspend fun getSingleUser( id:String):Response<UserResponse>


