package com.example.oldpeoplecareapp.model.entity

data class UserPost(
    var fullname: String,
    var email: String,
    var phone: String,
    var dateOfBirth: String,
    var gender: String,
    var registAs: String,
    var password: String
    )
