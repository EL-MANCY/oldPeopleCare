package com.example.oldpeoplecareapp.model.remote

import com.example.oldpeoplecareapp.model.entity.UserPost
import com.example.oldpeoplecareapp.model.entity.UserResponse
import retrofit2.Response
import retrofit2.http.*

interface ServiceAPI {
    //Registration
    @FormUrlEncoded
    @POST("/auth/signup")
    suspend fun addNewUser(
        @Field("fullname") fullname: String,
        @Field("email") email: String,
        @Field("phone") phone: String,
        @Field("dateOfBirth") dateOfBirth: String,
        @Field("gender") gender: String,
        @Field("registAs") registAs: String,
        @Field("password") password: String
    ): Response<UserResponse>

}









//    @GET("user/")
//    suspend fun getSingleUser(@Query("id") id:String):Response<UserResponse>


