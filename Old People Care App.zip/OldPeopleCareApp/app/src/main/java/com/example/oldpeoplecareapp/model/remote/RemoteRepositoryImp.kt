package com.example.oldpeoplecareapp.model.remote

import com.example.oldpeoplecareapp.model.entity.UserPost
import com.example.oldpeoplecareapp.model.entity.UserResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response
import retrofit2.http.Field

class RemoteRepositoryImp(private val api: ServiceAPI):RemoteRepository {
    override suspend fun addNewUser(
        fullname: String, email: String, phone: String, dateOfBirth: String,
        gender: String, registAs: String, password: String
    ): Response<UserResponse> {
        return withContext(Dispatchers.IO) {
            api.addNewUser(
                fullname,
                email,
                phone,
                dateOfBirth,
                gender,
                registAs,
                password
            )
        }
    }
}







//    override suspend fun getSingleUser(id: String): Response<UserResponse> {
//        return withContext(Dispatchers.IO){
//            api.getSingleUser(id)
//        }
//    }
